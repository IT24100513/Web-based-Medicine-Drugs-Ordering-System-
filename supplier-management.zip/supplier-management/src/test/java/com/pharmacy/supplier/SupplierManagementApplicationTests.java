package com.pharmacy.supplier;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupplierManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
