package com.pharmacy.supplier;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class SupplierService {
    @Autowired
    private SupplierRepository repository;

    @Autowired
    private SupplierFactory supplierFactory;

    public Page<Supplier> listAll(String search, int page) {
        int size = 10; // Fixed page size
        Pageable pageable = PageRequest.of(page, size);
        if (search == null || search.trim().isEmpty()) {
            return repository.findByStatus(Supplier.Status.ACTIVE, pageable);
        } else {
            return repository.findBySearch(search, pageable);
        }
    }

    public Supplier save(Supplier supplier) {
        Supplier newSupplier;
        if (supplier.getSupplierId() == null) {
            newSupplier = supplierFactory.createSupplier(
                    supplier.getSupplierName(),
                    supplier.getLine1(),
                    supplier.getLine2(),
                    supplier.getCity(),
                    supplier.getDistrict(),
                    supplier.getPostalCode(),
                    supplier.getCountry(),
                    supplier.getPhoneNumber(),
                    supplier.getEmail()
            );
        } else {
            newSupplier = supplierFactory.updateSupplier(
                    supplier.getSupplierId(),
                    supplier.getSupplierName(),
                    supplier.getLine1(),
                    supplier.getLine2(),
                    supplier.getCity(),
                    supplier.getDistrict(),
                    supplier.getPostalCode(),
                    supplier.getCountry(),
                    supplier.getPhoneNumber(),
                    supplier.getEmail(),
                    supplier.getStatus()
            );
        }
        return repository.save(newSupplier);
    }

    public Supplier get(Integer id) {
        return findById(id).orElseThrow(() -> new RuntimeException("Supplier not found"));
    }

    public Optional<Supplier> findById(Integer id) {
        return repository.findById(id);
    }

    public void delete(Integer id) {
        Optional<Supplier> optional = findById(id);
        optional.ifPresent(supplier -> {
            supplier.setStatus(Supplier.Status.INACTIVE);
            save(supplier);
        });
    }
}