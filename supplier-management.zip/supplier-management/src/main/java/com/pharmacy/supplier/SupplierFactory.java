package com.pharmacy.supplier;

import org.springframework.stereotype.Component;

@Component
public class SupplierFactory {

    public Supplier createSupplier(String supplierName, String line1, String line2, String city,
                                   String district, String postalCode, String country,
                                   String phoneNumber, String email) {
        Supplier supplier = new Supplier();
        supplier.setSupplierName(supplierName);
        supplier.setLine1(line1);
        supplier.setLine2(line2);
        supplier.setCity(city);
        supplier.setDistrict(district);
        supplier.setPostalCode(postalCode);
        supplier.setCountry(country);
        supplier.setPhoneNumber(phoneNumber);
        supplier.setEmail(email);
        supplier.setStatus(Supplier.Status.ACTIVE);
        return supplier;
    }

    public Supplier updateSupplier(Integer supplierId, String supplierName, String line1, String line2,
                                   String city, String district, String postalCode, String country,
                                   String phoneNumber, String email, Supplier.Status status) {
        Supplier supplier = new Supplier();
        supplier.setSupplierId(supplierId);
        supplier.setSupplierName(supplierName);
        supplier.setLine1(line1);
        supplier.setLine2(line2);
        supplier.setCity(city);
        supplier.setDistrict(district);
        supplier.setPostalCode(postalCode);
        supplier.setCountry(country);
        supplier.setPhoneNumber(phoneNumber);
        supplier.setEmail(email);
        supplier.setStatus(status);
        return supplier;
    }
}